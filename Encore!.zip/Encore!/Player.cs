﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace actualGame
{
    internal class Player
    {
        //variables
        public string playerName;

        //basic constructor
        public Player()
        {
            //default values
            playerName = "Ryuusei Tsubasa";


        }

    }
}
