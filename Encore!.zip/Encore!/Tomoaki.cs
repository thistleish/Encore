﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace actualGame
{
    public class Tomoaki : Idol
    {
        public Tomoaki(string _name, string _fullName, string _suit) : base(_name, _fullName, _suit)
        {
            firstName = "Tomoaki";
            fullName = "Tomoaki Kobayashi";
            suit = "dimaond";
        }

        //tomoaki's dialogue
        public override void Dialogue(string dialogue)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(dialogue);
            Console.ResetColor();
        }

    }
}
