﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace actualGame
{
    internal class Program
    {
        static void Main()
        {
            //changing console title
            Console.Title = "Encore!";

            //instantiate the game object
            Game game1 = new Game();

            //instantiate the player object
            Player player = new Player();


            //instantiate the boys
            Haruka haruka = new Haruka("Haruka", "Haruka Amami", "spade");
            Akira akira = new Akira("Akira", "Akira Sakamoto", "heart");
            Tomoaki tomoaki = new Tomoaki("Tomoaki", "Tomoaki Kobayashi", "diamond");

            //run intro scene
            game1.IntroScene();

            haruka.Dialogue(Game.HarukaDialogueArray[0]);
            Console.ReadKey();
            akira.Dialogue(Game.AkiraDialogueArray[0]);
            Console.ReadKey();
            tomoaki.Dialogue(Game.TomoakiDialogueArray[0]);
            Console.ReadKey();
        }
    }
}
