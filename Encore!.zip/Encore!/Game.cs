﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace actualGame
{
    internal class Game
    {

        //IM FOUASDHUOGHSNOG FUC,IGNG KILL THIS VARIABLE
        string playerName;

        //THE MUSEUM OF ARRAYS
        //i'm keeping all of my narrative, dialogue, and otherwise text-based things here
        //arrays are sorted by intro, scene, character, etc. to avoid making arrays with numbers big enough that i'll end up confusing them

        //INTRO ARRAY 
        string[] IntroArray = new string[]
        {
            //0
            @"
.------..------..------..------..------..------..------.
|E.--. ||N.--. ||C.--. ||O.--. ||R.--. ||E.--. ||!.--. |
| (\/) || :(): || :/\: || :/\: || :(): || (\/) || (\/) |
| :\/: || ()() || :\/: || :\/: || ()() || :\/: || :\/: |
| '--'E|| '--'N|| '--'C|| '--'O|| '--'R|| '--'E|| '--'!|
`------'`------'`------'`------'`------'`------'`------'
",
            //1            
            "\nWelcome to Encore!",

            //2
            "\nYou are a a member of an idol group consisting of four members--one for each card suit. You are the Club! Tonight is your debut performance, and you have to give the audience the show of a lifetime.",
            
            //3
            "\nWhat's your name, idol?",

            //4
            "Your idol name is {0}.", //{0} is a placeholder for playerName

            //5
            "\nCan you ace your performance? Good luck, and make sure you play your cards right!"



        };

        //

        //REHEARSAL SCENE ARRAY

        //PERFORMANCE SCENE ARRAY

        //ENDINGS ARRAY

        //HARUKA DIALOGUE ARRAY
        public static string[] HarukaDialogueArray = new string[]
        {

            "hiiro test dialogue!",



        };


        //TOMOAKI DIALOGUE ARRAY
       public static string[] TomoakiDialogueArray = new string[]
        {


            "tatsumi test dialogue"


        };


        //AKIRA DIALOGUE ARRAY
       public static string[] AkiraDialogueArray = new string[]
        {


            "aira test dialogue"
          

        };



        ////instantiate the boys

        //Haruka haruka = new Haruka("Haruka", "Haruka Amami", "spade");
        //Akira akira = new Akira("Akira", "Akira Sakamoto", "heart");
        //Tomoaki tomoaki = new Tomoaki("Tomoaki", "Tomoaki Kobayashi", "diamond");

        //creating the scene to run the title screen
        public void IntroScene()
        {

            //writing the intro
            Console.WriteLine(IntroArray[0]);
            Console.WriteLine(IntroArray[1]);
            Console.WriteLine(IntroArray[2]);
            Console.ReadKey();

            //getting player name
            Console.WriteLine(IntroArray[3]);
            playerName = Console.ReadLine();

            //converting player name to proper capitalization
            TextInfo textInfo = CultureInfo.CurrentCulture.TextInfo;
            playerName = textInfo.ToTitleCase(playerName);

            //insert playername into index 4
            Console.WriteLine(string.Format(IntroArray[4], playerName));

            Console.WriteLine(IntroArray[5]);

            Console.ReadKey();
        }
        


    }
}
