﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace actualGame
{
    public class Haruka : Idol
    {
        //haruka's constructor
        public Haruka(string _name, string _fullName, string _suit) : base(_name, _fullName, _suit)
        {
            firstName = "Haruka";
            fullName = "Haruka Amami";
            suit = "spade";
        }

        //haruka's dialogue
        public override void Dialogue(string dialogue)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine(dialogue);
            Console.ResetColor();
        }
    }
}
