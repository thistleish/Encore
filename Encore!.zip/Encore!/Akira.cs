﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace actualGame
{
    public class Akira : Idol
    {

        public Akira(string _name, string _fullName, string _suit) : base(_name, _fullName, _suit)
        {
            firstName = "Akira";
            fullName = "Akira Sakamoto";
            suit = "heart";
        }

        //akira's dialogue
        public override void Dialogue(string dialogue)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(dialogue);
            Console.ResetColor();
        }
    }
}
