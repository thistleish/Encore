﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace actualGame
{
    public class Idol
    {
        //adding the local variables
        protected string firstName;
        protected string fullName;
        protected string suit;
        int affinityPoints;

        //creating an overloaded constructor
        public Idol(string _firstName, string _fullName, string _suit)
        {

            //default
            affinityPoints = 0;

            //making the variables match the input ones
            firstName = _firstName;
            fullName = _fullName;
            suit = _suit;

        }

        //idol dialogue method
        //to be overridden in the child classes later
        public virtual void Dialogue(string dialogue)
        {
            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine("Your dialogue method didn't attach itself to a child class, for some reason. ERROR ERROR ERROR !!!!"); //placeholder, because this should never NOT be overridden and i want to know when it fails to do so
            Console.ResetColor();
        } 
        
        //status method
        //easy way to see the idol's status at the current time
        public void Status()
        {
            Console.WriteLine($"{firstName}'s affinity points are currently at {affinityPoints}.");
            Console.ReadKey();
        }

        //methods to raise and lower affinity points
        public void raiseAffinity()
        {
            affinityPoints++;
        }

        public void lowerAffinity()
        {
            affinityPoints--;
        }

    }
}
