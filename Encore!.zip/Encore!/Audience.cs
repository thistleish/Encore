﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace actualGame
{
    internal class Audience
    {
        //variables
        int audiencePoints = 0;

        public Audience()
        {



        }



    }
}
